package com.example.component;

import org.springframework.stereotype.Component;

@Component
public class CourseComponent {

    public String getCourse() {
        return "Course: Java";
    }
}