// ===============================
// RESULT PAGE SCRIPT
// ===============================

function loadResults(){

    fetch('/api/results')
    .then(res => res.json())
    .then(data => {

        const tbody = document.querySelector("#results-table tbody");
        if(!tbody) return;

        tbody.innerHTML = "";

        if(data.length === 0){
            tbody.innerHTML = "<tr><td colspan='4'>No Results Found</td></tr>";
            return;
        }

        data.forEach(result => {
            const tr = document.createElement("tr");

            tr.innerHTML = `
                <td>${result.title}</td>
                <td>${result.score}</td>
                <td>${result.percentage}%</td>
                <td>${result.status}</td>
            `;

            tbody.appendChild(tr);
        });
    })
    .catch(err => {
        console.error(err);
        alert("Server Error");
    });
}

loadResults();