// ===============================
// ADMIN PANEL SCRIPT
// ===============================

// Load Exams in dropdown
function loadExams() {
    fetch('/api/exams')
    .then(res => res.json())
    .then(data => {
        const select = document.getElementById("exam-select");
        if(!select) return;

        select.innerHTML = '<option value="">Select Exam</option>';

        data.forEach(exam => {
            const option = document.createElement("option");
            option.value = exam.id;
            option.textContent = exam.title;
            select.appendChild(option);
        });
    })
    .catch(err => console.error("Error loading exams:", err));
}


// ===============================
// ADD EXAM
// ===============================
const addExamBtn = document.getElementById("add-exam-btn");

if(addExamBtn){
    addExamBtn.addEventListener("click", () => {

        const title = document.getElementById("exam-title").value.trim();
        const description = document.getElementById("exam-desc").value.trim();
        const total_marks = document.getElementById("exam-marks").value.trim();

        if(!title || !total_marks){
            alert("Please fill required fields");
            return;
        }

        fetch('/api/exams/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, description, total_marks })
        })
        .then(res => res.json())
        .then(data => {
            alert("Exam Added Successfully ✅");
            loadExams();
        })
        .catch(err => {
            console.error(err);
            alert("Server Error");
        });
    });
}


// ===============================
// ADD QUESTION
// ===============================
const addQuestionBtn = document.getElementById("add-question-btn");

if(addQuestionBtn){
    addQuestionBtn.addEventListener("click", () => {

        const exam_id = document.getElementById("exam-select").value;
        const question = document.getElementById("question-text").value.trim();
        const option1 = document.getElementById("opt1").value.trim();
        const option2 = document.getElementById("opt2").value.trim();
        const option3 = document.getElementById("opt3").value.trim();
        const option4 = document.getElementById("opt4").value.trim();
        const correct_answer = document.getElementById("correct-answer").value.trim();
        const marks = document.getElementById("marks").value.trim();

        if(!exam_id || !question || !correct_answer){
            alert("Please fill all required fields");
            return;
        }

        fetch('/api/questions/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                exam_id,
                question,
                option1,
                option2,
                option3,
                option4,
                correct_answer,
                marks
            })
        })
        .then(res => res.json())
        .then(data => {
            alert("Question Added Successfully ✅");
        })
        .catch(err => {
            console.error(err);
            alert("Server Error");
        });
    });
}


// ===============================
// LOAD ALL RESULTS (ADMIN VIEW)
// ===============================
function loadAllResults(){
    fetch('/api/results')
    .then(res => res.json())
    .then(data => {
        const tbody = document.querySelector("#results-table tbody");
        if(!tbody) return;

        tbody.innerHTML = "";

        data.forEach(result => {
            const tr = document.createElement("tr");

            tr.innerHTML = `
                <td>${result.name}</td>
                <td>${result.title}</td>
                <td>${result.score}</td>
                <td>${result.percentage}%</td>
                <td>${result.status}</td>
            `;

            tbody.appendChild(tr);
        });
    })
    .catch(err => console.error("Error loading results:", err));
}


// Initial Load
loadExams();
loadAllResults();