// ===============================
// STUDENT DASHBOARD
// ===============================

function loadExamsForStudent(){
    fetch('/api/exams')
    .then(res => res.json())
    .then(data => {
        const examList = document.getElementById("exam-list");
        if(!examList) return;

        examList.innerHTML = "";

        data.forEach(exam => {
            const div = document.createElement("div");
            div.classList.add("card");

            div.innerHTML = `
                <h3>${exam.title}</h3>
                <p>${exam.description || ""}</p>
                <button onclick="startExam(${exam.id})">Start Exam</button>
            `;

            examList.appendChild(div);
        });
    })
    .catch(err => console.error("Error:", err));
}

function startExam(id){
    window.location.href = `exam.html?exam_id=${id}`;
}


// ===============================
// LOAD STUDENT RESULTS
// ===============================
function loadStudentResults(){
    fetch('/api/results')
    .then(res => res.json())
    .then(data => {

        const tbody = document.querySelector("#results-table tbody");
        if(!tbody) return;

        tbody.innerHTML = "";

        data.forEach(result => {
            const tr = document.createElement("tr");

            tr.innerHTML = `
                <td>${result.title}</td>
                <td>${result.score}</td>
                <td>${result.percentage}%</td>
                <td>${result.status}</td>
            `;

            tbody.appendChild(tr);
        });
    })
    .catch(err => console.error("Error:", err));
}


// ===============================
// IF PAGE IS DASHBOARD
// ===============================
if(document.getElementById("exam-list")){
    loadExamsForStudent();
}

if(document.getElementById("results-table")){
    loadStudentResults();
}