// Navigation
function navigate(page) {
    window.location.href = page;
}

// Simple Question Data
let questionData = {
    question: "What is 2 + 2?",
    options: ["2", "3", "4", "5"],
    correct: "4"
};

// Load Question Automatically
if (document.getElementById("question")) {
    document.getElementById("question").innerText = questionData.question;

    let optionsDiv = document.getElementById("options");

    questionData.options.forEach(option => {
        let btn = document.createElement("button");
        btn.innerText = option;
        btn.onclick = () => selectAnswer(option);
        optionsDiv.appendChild(btn);
    });
}

let selectedAnswer = "";

function selectAnswer(answer) {
    selectedAnswer = answer;
}

function submitAnswer() {
    if (selectedAnswer === questionData.correct) {
        localStorage.setItem("score", "1 / 1 ✅");
    } else {
        localStorage.setItem("score", "0 / 1 ❌");
    }

    navigate("result.html");
}

// Show Result
if (document.getElementById("scoreDisplay")) {
    let score = localStorage.getItem("score");
    document.getElementById("scoreDisplay").innerText = score || "No result yet";
}

// Admin Add Question
function addQuestion() {
    let input = document.getElementById("newQuestion");
    let list = document.getElementById("questionList");

    if (input.value.trim() !== "") {
        let li = document.createElement("li");
        li.innerText = input.value;
        list.appendChild(li);
        input.value = "";
    }
}