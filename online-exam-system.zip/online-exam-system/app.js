const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Database
const mysql = require('mysql2');
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',           // your MySQL username
    password: 'reshu@403216',   // your MySQL password
    database: 'online_exam_system'
});

// Make db accessible in routes
app.use((req, res, next) => {
    req.db = db;
    next();
});

// Routes
const authRoutes = require('./routes/auth');
const examRoutes = require('./routes/exams');
const questionRoutes = require('./routes/questions');
const resultRoutes = require('./routes/results');

app.use('/api/auth', authRoutes);
app.use('/api/exams', examRoutes);
app.use('/api/questions', questionRoutes);
app.use('/api/results', resultRoutes);

// Serve main login page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Start server
app.listen(3000, () => console.log("Server running on http://localhost:3000"));