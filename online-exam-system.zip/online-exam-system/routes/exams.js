const express = require('express');
const router = express.Router();

// GET all exams
router.get('/', (req, res) => {
    req.db.query('SELECT * FROM exams', (err, results) => {
        if(err) return res.status(500).json([]);
        res.json(results);
    });
});

// POST add exam (Admin only)
router.post('/add', (req, res) => {
    const { title, description, total_marks } = req.body;
    req.db.query(
        'INSERT INTO exams (title, description, total_marks) VALUES (?, ?, ?)',
        [title, description, total_marks],
        (err, result) => {
            if(err) return res.status(500).json({ success: false, message: 'DB Error' });
            res.json({ success: true });
        }
    );
});

module.exports = router;