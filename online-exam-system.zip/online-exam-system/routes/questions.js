const express = require('express');
const router = express.Router();

// GET questions by exam_id
router.get('/:examId', (req, res) => {
    const examId = req.params.examId;
    req.db.query('SELECT * FROM questions WHERE exam_id=?', [examId], (err, results) => {
        if(err) return res.status(500).json([]);
        res.json(results);
    });
});

// POST add question (Admin only)
router.post('/add', (req, res) => {
    const { exam_id, question, option1, option2, option3, option4, correct_answer, marks } = req.body;

    req.db.query(
        'INSERT INTO questions (exam_id, question, option1, option2, option3, option4, correct_answer, marks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [exam_id, question, option1, option2, option3, option4, correct_answer, marks],
        (err, result) => {
            if(err) return res.status(500).json({ success: false, message: 'DB Error' });
            res.json({ success: true });
        }
    );
});

module.exports = router;