const express = require('express');
const router = express.Router();

// POST /api/auth/login
router.post('/login', (req, res) => {
    const { name, email, password } = req.body;
    const db = req.db;

    db.query('SELECT * FROM users WHERE email=?', [email], (err, results) => {
        if(err) return res.status(500).json({ message: err.message });

        if(results.length > 0){
            const user = results[0];
            if(user.password === password){
                res.json({ id: user.id, name: user.name, role: user.role });
            } else {
                res.status(401).json({ message: "Invalid password" });
            }
        } else {
            if(!name) return res.status(400).json({ message: "Name is required for new student" });

            db.query(
                "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'STUDENT')",
                [name, email, password],
                (err2, result2) => {
                    if(err2) return res.status(500).json({ message: err2.message });
                    res.json({ id: result2.insertId, name, role: "STUDENT" });
                }
            );
        }
    });
});

module.exports = router;