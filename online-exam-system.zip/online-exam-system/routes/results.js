const express = require('express');
const router = express.Router();

// GET all results (Admin: all results, Student: their own)
router.get('/', (req, res) => {
    const db = req.db;

    // For demo, returning all results
    db.query(
        `SELECT r.id, u.name, e.title, r.score, r.percentage, r.status
         FROM results r
         JOIN users u ON r.user_id = u.id
         JOIN exams e ON r.exam_id = e.id`,
        (err, results) => {
            if(err) return res.status(500).json([]);
            res.json(results);
        }
    );
});

// POST submit exam
router.post('/:examId/submit', (req, res) => {
    const db = req.db;
    const examId = req.params.examId;
    const { answers } = req.body;

    let score = 0;
    let totalMarks = 0;
    const tasks = [];

    answers.forEach(ans => {
        tasks.push(new Promise((resolve, reject) => {
            db.query('SELECT correct_answer, marks FROM questions WHERE id=?', [ans.question_id], (err, results) => {
                if(err) return reject(err);

                const correct = results[0].correct_answer;
                const marks = results[0].marks;
                totalMarks += marks;
                const isCorrect = ans.selected_answer === correct;
                if(isCorrect) score += marks;

                // Save user answer
                db.query(
                    'INSERT INTO user_answers (user_id, exam_id, question_id, selected_answer, is_correct) VALUES (?, ?, ?, ?, ?)',
                    [1, examId, ans.question_id, ans.selected_answer, isCorrect],
                    (err2) => err2 ? reject(err2) : resolve()
                );
            });
        }));
    });

    Promise.all(tasks)
    .then(() => {
        const percentage = ((score / totalMarks) * 100).toFixed(2);
        const status = percentage >= 40 ? 'PASS' : 'FAIL';

        db.query(
            'INSERT INTO results (user_id, exam_id, score, percentage, status) VALUES (?, ?, ?, ?, ?)',
            [1, examId, score, percentage, status],
            (err) => {
                if(err) return res.status(500).json({ message: 'Error saving result' });
                res.json({ score, percentage, status });
            }
        );
    })
    .catch(err => res.status(500).json({ message: err.message }));
});

module.exports = router;