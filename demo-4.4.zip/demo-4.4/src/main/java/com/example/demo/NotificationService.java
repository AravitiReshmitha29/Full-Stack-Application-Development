package com.example.demo;

public interface NotificationService {
	String sendNotification();

}
